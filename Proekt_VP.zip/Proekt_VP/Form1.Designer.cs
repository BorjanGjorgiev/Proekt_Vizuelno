﻿namespace Proekt_VP
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.guna2CustomGradientPanel1 = new Guna.UI2.WinForms.Guna2CustomGradientPanel();
            this.label33 = new System.Windows.Forms.Label();
            this.label13 = new System.Windows.Forms.Label();
            this.guna2ShadowPanel1 = new Guna.UI2.WinForms.Guna2ShadowPanel();
            this.tbOsvoeniSredstva = new System.Windows.Forms.TextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.pictureBox3 = new System.Windows.Forms.PictureBox();
            this.pictureBox2 = new System.Windows.Forms.PictureBox();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.panel16 = new System.Windows.Forms.Panel();
            this.label31 = new System.Windows.Forms.Label();
            this.label32 = new System.Windows.Forms.Label();
            this.panel15 = new System.Windows.Forms.Panel();
            this.label30 = new System.Windows.Forms.Label();
            this.label17 = new System.Windows.Forms.Label();
            this.panel13 = new System.Windows.Forms.Panel();
            this.label16 = new System.Windows.Forms.Label();
            this.label29 = new System.Windows.Forms.Label();
            this.panel12 = new System.Windows.Forms.Panel();
            this.label15 = new System.Windows.Forms.Label();
            this.label28 = new System.Windows.Forms.Label();
            this.panel11 = new System.Windows.Forms.Panel();
            this.label10 = new System.Windows.Forms.Label();
            this.label27 = new System.Windows.Forms.Label();
            this.panel10 = new System.Windows.Forms.Panel();
            this.label11 = new System.Windows.Forms.Label();
            this.label26 = new System.Windows.Forms.Label();
            this.panel9 = new System.Windows.Forms.Panel();
            this.label12 = new System.Windows.Forms.Label();
            this.label25 = new System.Windows.Forms.Label();
            this.panel8 = new System.Windows.Forms.Panel();
            this.label2 = new System.Windows.Forms.Label();
            this.label24 = new System.Windows.Forms.Label();
            this.panel7 = new System.Windows.Forms.Panel();
            this.label3 = new System.Windows.Forms.Label();
            this.label23 = new System.Windows.Forms.Label();
            this.panel6 = new System.Windows.Forms.Panel();
            this.label4 = new System.Windows.Forms.Label();
            this.label22 = new System.Windows.Forms.Label();
            this.panel5 = new System.Windows.Forms.Panel();
            this.label5 = new System.Windows.Forms.Label();
            this.label21 = new System.Windows.Forms.Label();
            this.panel4 = new System.Windows.Forms.Panel();
            this.label6 = new System.Windows.Forms.Label();
            this.label20 = new System.Windows.Forms.Label();
            this.panel3 = new System.Windows.Forms.Panel();
            this.label7 = new System.Windows.Forms.Label();
            this.label19 = new System.Windows.Forms.Label();
            this.panel2 = new System.Windows.Forms.Panel();
            this.label8 = new System.Windows.Forms.Label();
            this.label18 = new System.Windows.Forms.Label();
            this.panel1 = new System.Windows.Forms.Panel();
            this.label9 = new System.Windows.Forms.Label();
            this.label14 = new System.Windows.Forms.Label();
            this.pictureBox4 = new System.Windows.Forms.PictureBox();
            this.btnOdgovori = new Guna.UI2.WinForms.Guna2Button();
            this.panelPhone = new System.Windows.Forms.Panel();
            this.label35 = new System.Windows.Forms.Label();
            this.label34 = new System.Windows.Forms.Label();
            this.guna2Button3 = new Guna.UI2.WinForms.Guna2Button();
            this.guna2Button2 = new Guna.UI2.WinForms.Guna2Button();
            this.panel17 = new System.Windows.Forms.Panel();
            this.NumD = new System.Windows.Forms.Label();
            this.NumC = new System.Windows.Forms.Label();
            this.NumB = new System.Windows.Forms.Label();
            this.NumA = new System.Windows.Forms.Label();
            this.progressBar4 = new System.Windows.Forms.ProgressBar();
            this.progressBar3 = new System.Windows.Forms.ProgressBar();
            this.progressBar2 = new System.Windows.Forms.ProgressBar();
            this.progressBar1 = new System.Windows.Forms.ProgressBar();
            this.label40 = new System.Windows.Forms.Label();
            this.label39 = new System.Windows.Forms.Label();
            this.label38 = new System.Windows.Forms.Label();
            this.label37 = new System.Windows.Forms.Label();
            this.label36 = new System.Windows.Forms.Label();
            this.OptionA = new System.Windows.Forms.Button();
            this.OptionB = new System.Windows.Forms.Button();
            this.OptionC = new System.Windows.Forms.Button();
            this.OptionD = new System.Windows.Forms.Button();
            this.timer1 = new System.Windows.Forms.Timer(this.components);
            this.guna2CustomGradientPanel1.SuspendLayout();
            this.guna2ShadowPanel1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox3)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            this.panel16.SuspendLayout();
            this.panel15.SuspendLayout();
            this.panel13.SuspendLayout();
            this.panel12.SuspendLayout();
            this.panel11.SuspendLayout();
            this.panel10.SuspendLayout();
            this.panel9.SuspendLayout();
            this.panel8.SuspendLayout();
            this.panel7.SuspendLayout();
            this.panel6.SuspendLayout();
            this.panel5.SuspendLayout();
            this.panel4.SuspendLayout();
            this.panel3.SuspendLayout();
            this.panel2.SuspendLayout();
            this.panel1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox4)).BeginInit();
            this.panelPhone.SuspendLayout();
            this.panel17.SuspendLayout();
            this.SuspendLayout();
            // 
            // guna2CustomGradientPanel1
            // 
            this.guna2CustomGradientPanel1.BackColor = System.Drawing.Color.White;
            this.guna2CustomGradientPanel1.BorderRadius = 100;
            this.guna2CustomGradientPanel1.Controls.Add(this.label33);
            this.guna2CustomGradientPanel1.Controls.Add(this.label13);
            this.guna2CustomGradientPanel1.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(64)))));
            this.guna2CustomGradientPanel1.FillColor2 = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(64)))));
            this.guna2CustomGradientPanel1.FillColor3 = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(64)))));
            this.guna2CustomGradientPanel1.Location = new System.Drawing.Point(116, 292);
            this.guna2CustomGradientPanel1.Name = "guna2CustomGradientPanel1";
            this.guna2CustomGradientPanel1.Size = new System.Drawing.Size(980, 123);
            this.guna2CustomGradientPanel1.TabIndex = 0;
            // 
            // label33
            // 
            this.label33.BackColor = System.Drawing.Color.Transparent;
            this.label33.Font = new System.Drawing.Font("Arial Unicode MS", 13.8F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label33.ForeColor = System.Drawing.Color.Transparent;
            this.label33.Location = new System.Drawing.Point(214, 29);
            this.label33.Name = "label33";
            this.label33.Size = new System.Drawing.Size(688, 68);
            this.label33.TabIndex = 1;
            this.label33.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.label33.Click += new System.EventHandler(this.label33_Click);
            // 
            // label13
            // 
            this.label13.AutoSize = true;
            this.label13.BackColor = System.Drawing.Color.Transparent;
            this.label13.Font = new System.Drawing.Font("Arial Unicode MS", 13.8F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label13.ForeColor = System.Drawing.Color.Transparent;
            this.label13.Location = new System.Drawing.Point(141, 37);
            this.label13.Name = "label13";
            this.label13.Size = new System.Drawing.Size(51, 31);
            this.label13.TabIndex = 0;
            this.label13.Text = "NO";
            // 
            // guna2ShadowPanel1
            // 
            this.guna2ShadowPanel1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(64)))));
            this.guna2ShadowPanel1.Controls.Add(this.tbOsvoeniSredstva);
            this.guna2ShadowPanel1.Controls.Add(this.label1);
            this.guna2ShadowPanel1.Controls.Add(this.pictureBox3);
            this.guna2ShadowPanel1.Controls.Add(this.pictureBox2);
            this.guna2ShadowPanel1.Controls.Add(this.pictureBox1);
            this.guna2ShadowPanel1.Controls.Add(this.panel16);
            this.guna2ShadowPanel1.Controls.Add(this.panel15);
            this.guna2ShadowPanel1.Controls.Add(this.panel13);
            this.guna2ShadowPanel1.Controls.Add(this.panel12);
            this.guna2ShadowPanel1.Controls.Add(this.panel11);
            this.guna2ShadowPanel1.Controls.Add(this.panel10);
            this.guna2ShadowPanel1.Controls.Add(this.panel9);
            this.guna2ShadowPanel1.Controls.Add(this.panel8);
            this.guna2ShadowPanel1.Controls.Add(this.panel7);
            this.guna2ShadowPanel1.Controls.Add(this.panel6);
            this.guna2ShadowPanel1.Controls.Add(this.panel5);
            this.guna2ShadowPanel1.Controls.Add(this.panel4);
            this.guna2ShadowPanel1.Controls.Add(this.panel3);
            this.guna2ShadowPanel1.Controls.Add(this.panel2);
            this.guna2ShadowPanel1.Controls.Add(this.panel1);
            this.guna2ShadowPanel1.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(64)))));
            this.guna2ShadowPanel1.Location = new System.Drawing.Point(1173, 32);
            this.guna2ShadowPanel1.Name = "guna2ShadowPanel1";
            this.guna2ShadowPanel1.ShadowColor = System.Drawing.Color.Navy;
            this.guna2ShadowPanel1.Size = new System.Drawing.Size(296, 690);
            this.guna2ShadowPanel1.TabIndex = 5;
            // 
            // tbOsvoeniSredstva
            // 
            this.tbOsvoeniSredstva.Enabled = false;
            this.tbOsvoeniSredstva.Location = new System.Drawing.Point(184, 111);
            this.tbOsvoeniSredstva.Name = "tbOsvoeniSredstva";
            this.tbOsvoeniSredstva.Size = new System.Drawing.Size(100, 22);
            this.tbOsvoeniSredstva.TabIndex = 50;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.label1.Location = new System.Drawing.Point(22, 114);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(156, 16);
            this.label1.TabIndex = 49;
            this.label1.Text = "ОСВОЕНИ СРЕДСТВА:";
            // 
            // pictureBox3
            // 
            this.pictureBox3.Image = global::Proekt_VP.Properties.Resources.gleda4i;
            this.pictureBox3.Location = new System.Drawing.Point(197, 14);
            this.pictureBox3.Name = "pictureBox3";
            this.pictureBox3.Size = new System.Drawing.Size(77, 78);
            this.pictureBox3.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox3.TabIndex = 48;
            this.pictureBox3.TabStop = false;
            this.pictureBox3.Click += new System.EventHandler(this.pictureBox3_Click);
            // 
            // pictureBox2
            // 
            this.pictureBox2.Image = global::Proekt_VP.Properties.Resources.povikaj_prijatel;
            this.pictureBox2.Location = new System.Drawing.Point(102, 14);
            this.pictureBox2.Name = "pictureBox2";
            this.pictureBox2.Size = new System.Drawing.Size(77, 78);
            this.pictureBox2.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox2.TabIndex = 47;
            this.pictureBox2.TabStop = false;
            this.pictureBox2.Click += new System.EventHandler(this.pictureBox2_Click);
            // 
            // pictureBox1
            // 
            this.pictureBox1.Image = global::Proekt_VP.Properties.Resources.peesetpeeset;
            this.pictureBox1.Location = new System.Drawing.Point(19, 14);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(77, 78);
            this.pictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox1.TabIndex = 46;
            this.pictureBox1.TabStop = false;
            this.pictureBox1.Click += new System.EventHandler(this.pictureBox1_Click);
            // 
            // panel16
            // 
            this.panel16.BackColor = System.Drawing.Color.Transparent;
            this.panel16.Controls.Add(this.label31);
            this.panel16.Controls.Add(this.label32);
            this.panel16.Location = new System.Drawing.Point(25, 645);
            this.panel16.Name = "panel16";
            this.panel16.Size = new System.Drawing.Size(234, 26);
            this.panel16.TabIndex = 45;
            // 
            // label31
            // 
            this.label31.AutoSize = true;
            this.label31.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(64)))));
            this.label31.Font = new System.Drawing.Font("Arial Narrow", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label31.ForeColor = System.Drawing.SystemColors.ButtonFace;
            this.label31.Location = new System.Drawing.Point(16, 1);
            this.label31.Name = "label31";
            this.label31.Size = new System.Drawing.Size(19, 24);
            this.label31.TabIndex = 8;
            this.label31.Text = "1";
            // 
            // label32
            // 
            this.label32.AutoSize = true;
            this.label32.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(64)))));
            this.label32.Font = new System.Drawing.Font("Arial Narrow", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label32.ForeColor = System.Drawing.SystemColors.ButtonFace;
            this.label32.Location = new System.Drawing.Point(94, 1);
            this.label32.Name = "label32";
            this.label32.Size = new System.Drawing.Size(37, 24);
            this.label32.TabIndex = 13;
            this.label32.Text = "100";
            // 
            // panel15
            // 
            this.panel15.BackColor = System.Drawing.Color.Transparent;
            this.panel15.Controls.Add(this.label30);
            this.panel15.Controls.Add(this.label17);
            this.panel15.Location = new System.Drawing.Point(25, 162);
            this.panel15.Name = "panel15";
            this.panel15.Size = new System.Drawing.Size(234, 30);
            this.panel15.TabIndex = 44;
            // 
            // label30
            // 
            this.label30.AutoSize = true;
            this.label30.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(64)))));
            this.label30.Font = new System.Drawing.Font("Arial Narrow", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label30.ForeColor = System.Drawing.SystemColors.ButtonFace;
            this.label30.Location = new System.Drawing.Point(93, 4);
            this.label30.Name = "label30";
            this.label30.Size = new System.Drawing.Size(83, 24);
            this.label30.TabIndex = 29;
            this.label30.Text = "1,000,000";
            // 
            // label17
            // 
            this.label17.AutoSize = true;
            this.label17.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(64)))));
            this.label17.Font = new System.Drawing.Font("Arial Narrow", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label17.ForeColor = System.Drawing.SystemColors.ButtonFace;
            this.label17.Location = new System.Drawing.Point(16, 4);
            this.label17.Name = "label17";
            this.label17.Size = new System.Drawing.Size(28, 24);
            this.label17.TabIndex = 16;
            this.label17.Text = "15";
            // 
            // panel13
            // 
            this.panel13.BackColor = System.Drawing.Color.Transparent;
            this.panel13.Controls.Add(this.label16);
            this.panel13.Controls.Add(this.label29);
            this.panel13.Location = new System.Drawing.Point(25, 198);
            this.panel13.Name = "panel13";
            this.panel13.Size = new System.Drawing.Size(234, 30);
            this.panel13.TabIndex = 42;
            // 
            // label16
            // 
            this.label16.AutoSize = true;
            this.label16.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(64)))));
            this.label16.Font = new System.Drawing.Font("Arial Narrow", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label16.ForeColor = System.Drawing.SystemColors.ButtonFace;
            this.label16.Location = new System.Drawing.Point(16, 4);
            this.label16.Name = "label16";
            this.label16.Size = new System.Drawing.Size(28, 24);
            this.label16.TabIndex = 15;
            this.label16.Text = "14";
            // 
            // label29
            // 
            this.label29.AutoSize = true;
            this.label29.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(64)))));
            this.label29.Font = new System.Drawing.Font("Arial Narrow", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label29.ForeColor = System.Drawing.SystemColors.ButtonFace;
            this.label29.Location = new System.Drawing.Point(93, 4);
            this.label29.Name = "label29";
            this.label29.Size = new System.Drawing.Size(69, 24);
            this.label29.TabIndex = 28;
            this.label29.Text = "250,000";
            // 
            // panel12
            // 
            this.panel12.BackColor = System.Drawing.Color.Transparent;
            this.panel12.Controls.Add(this.label15);
            this.panel12.Controls.Add(this.label28);
            this.panel12.Location = new System.Drawing.Point(25, 234);
            this.panel12.Name = "panel12";
            this.panel12.Size = new System.Drawing.Size(234, 30);
            this.panel12.TabIndex = 41;
            // 
            // label15
            // 
            this.label15.AutoSize = true;
            this.label15.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(64)))));
            this.label15.Font = new System.Drawing.Font("Arial Narrow", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label15.ForeColor = System.Drawing.SystemColors.ButtonFace;
            this.label15.Location = new System.Drawing.Point(16, 4);
            this.label15.Name = "label15";
            this.label15.Size = new System.Drawing.Size(28, 24);
            this.label15.TabIndex = 14;
            this.label15.Text = "13";
            // 
            // label28
            // 
            this.label28.AutoSize = true;
            this.label28.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(64)))));
            this.label28.Font = new System.Drawing.Font("Arial Narrow", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label28.ForeColor = System.Drawing.SystemColors.ButtonFace;
            this.label28.Location = new System.Drawing.Point(93, 4);
            this.label28.Name = "label28";
            this.label28.Size = new System.Drawing.Size(69, 24);
            this.label28.TabIndex = 27;
            this.label28.Text = "100,000";
            // 
            // panel11
            // 
            this.panel11.BackColor = System.Drawing.Color.Transparent;
            this.panel11.Controls.Add(this.label10);
            this.panel11.Controls.Add(this.label27);
            this.panel11.Location = new System.Drawing.Point(25, 270);
            this.panel11.Name = "panel11";
            this.panel11.Size = new System.Drawing.Size(234, 30);
            this.panel11.TabIndex = 40;
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(64)))));
            this.label10.Font = new System.Drawing.Font("Arial Narrow", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label10.ForeColor = System.Drawing.SystemColors.ButtonFace;
            this.label10.Location = new System.Drawing.Point(16, 4);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(28, 24);
            this.label10.TabIndex = 9;
            this.label10.Text = "12";
            // 
            // label27
            // 
            this.label27.AutoSize = true;
            this.label27.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(64)))));
            this.label27.Font = new System.Drawing.Font("Arial Narrow", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label27.ForeColor = System.Drawing.SystemColors.ButtonFace;
            this.label27.Location = new System.Drawing.Point(93, 4);
            this.label27.Name = "label27";
            this.label27.Size = new System.Drawing.Size(60, 24);
            this.label27.TabIndex = 26;
            this.label27.Text = "50,000";
            // 
            // panel10
            // 
            this.panel10.BackColor = System.Drawing.Color.Transparent;
            this.panel10.Controls.Add(this.label11);
            this.panel10.Controls.Add(this.label26);
            this.panel10.Location = new System.Drawing.Point(25, 306);
            this.panel10.Name = "panel10";
            this.panel10.Size = new System.Drawing.Size(234, 28);
            this.panel10.TabIndex = 39;
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(64)))));
            this.label11.Font = new System.Drawing.Font("Arial Narrow", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label11.ForeColor = System.Drawing.SystemColors.ButtonFace;
            this.label11.Location = new System.Drawing.Point(16, 3);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(28, 24);
            this.label11.TabIndex = 10;
            this.label11.Text = "11";
            // 
            // label26
            // 
            this.label26.AutoSize = true;
            this.label26.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(64)))));
            this.label26.Font = new System.Drawing.Font("Arial Narrow", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label26.ForeColor = System.Drawing.SystemColors.ButtonFace;
            this.label26.Location = new System.Drawing.Point(94, 3);
            this.label26.Name = "label26";
            this.label26.Size = new System.Drawing.Size(60, 24);
            this.label26.TabIndex = 25;
            this.label26.Text = "20,000";
            // 
            // panel9
            // 
            this.panel9.BackColor = System.Drawing.Color.Transparent;
            this.panel9.Controls.Add(this.label12);
            this.panel9.Controls.Add(this.label25);
            this.panel9.Location = new System.Drawing.Point(25, 340);
            this.panel9.Name = "panel9";
            this.panel9.Size = new System.Drawing.Size(234, 30);
            this.panel9.TabIndex = 38;
            // 
            // label12
            // 
            this.label12.AutoSize = true;
            this.label12.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(64)))));
            this.label12.Font = new System.Drawing.Font("Arial Narrow", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label12.ForeColor = System.Drawing.SystemColors.ButtonFace;
            this.label12.Location = new System.Drawing.Point(16, 4);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(28, 24);
            this.label12.TabIndex = 11;
            this.label12.Text = "10";
            // 
            // label25
            // 
            this.label25.AutoSize = true;
            this.label25.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(64)))));
            this.label25.Font = new System.Drawing.Font("Arial Narrow", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label25.ForeColor = System.Drawing.SystemColors.ButtonFace;
            this.label25.Location = new System.Drawing.Point(94, 4);
            this.label25.Name = "label25";
            this.label25.Size = new System.Drawing.Size(60, 24);
            this.label25.TabIndex = 24;
            this.label25.Text = "10,000";
            // 
            // panel8
            // 
            this.panel8.BackColor = System.Drawing.Color.Transparent;
            this.panel8.Controls.Add(this.label2);
            this.panel8.Controls.Add(this.label24);
            this.panel8.Location = new System.Drawing.Point(25, 376);
            this.panel8.Name = "panel8";
            this.panel8.Size = new System.Drawing.Size(234, 28);
            this.panel8.TabIndex = 37;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(64)))));
            this.label2.Font = new System.Drawing.Font("Arial Narrow", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label2.ForeColor = System.Drawing.SystemColors.ButtonFace;
            this.label2.Location = new System.Drawing.Point(16, 2);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(19, 24);
            this.label2.TabIndex = 1;
            this.label2.Text = "9";
            // 
            // label24
            // 
            this.label24.AutoSize = true;
            this.label24.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(64)))));
            this.label24.Font = new System.Drawing.Font("Arial Narrow", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label24.ForeColor = System.Drawing.SystemColors.ButtonFace;
            this.label24.Location = new System.Drawing.Point(93, 2);
            this.label24.Name = "label24";
            this.label24.Size = new System.Drawing.Size(51, 24);
            this.label24.TabIndex = 23;
            this.label24.Text = "6,000";
            // 
            // panel7
            // 
            this.panel7.BackColor = System.Drawing.Color.Transparent;
            this.panel7.Controls.Add(this.label3);
            this.panel7.Controls.Add(this.label23);
            this.panel7.Location = new System.Drawing.Point(25, 410);
            this.panel7.Name = "panel7";
            this.panel7.Size = new System.Drawing.Size(234, 28);
            this.panel7.TabIndex = 36;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(64)))));
            this.label3.Font = new System.Drawing.Font("Arial Narrow", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label3.ForeColor = System.Drawing.SystemColors.ButtonFace;
            this.label3.Location = new System.Drawing.Point(16, 2);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(19, 24);
            this.label3.TabIndex = 2;
            this.label3.Text = "8";
            // 
            // label23
            // 
            this.label23.AutoSize = true;
            this.label23.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(64)))));
            this.label23.Font = new System.Drawing.Font("Arial Narrow", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label23.ForeColor = System.Drawing.SystemColors.ButtonFace;
            this.label23.Location = new System.Drawing.Point(93, 2);
            this.label23.Name = "label23";
            this.label23.Size = new System.Drawing.Size(51, 24);
            this.label23.TabIndex = 22;
            this.label23.Text = "4,000";
            // 
            // panel6
            // 
            this.panel6.BackColor = System.Drawing.Color.Transparent;
            this.panel6.Controls.Add(this.label4);
            this.panel6.Controls.Add(this.label22);
            this.panel6.Location = new System.Drawing.Point(25, 444);
            this.panel6.Name = "panel6";
            this.panel6.Size = new System.Drawing.Size(234, 28);
            this.panel6.TabIndex = 35;
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(64)))));
            this.label4.Font = new System.Drawing.Font("Arial Narrow", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label4.ForeColor = System.Drawing.SystemColors.ButtonFace;
            this.label4.Location = new System.Drawing.Point(16, 2);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(19, 24);
            this.label4.TabIndex = 3;
            this.label4.Text = "7";
            // 
            // label22
            // 
            this.label22.AutoSize = true;
            this.label22.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(64)))));
            this.label22.Font = new System.Drawing.Font("Arial Narrow", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label22.ForeColor = System.Drawing.SystemColors.ButtonFace;
            this.label22.Location = new System.Drawing.Point(93, 2);
            this.label22.Name = "label22";
            this.label22.Size = new System.Drawing.Size(51, 24);
            this.label22.TabIndex = 21;
            this.label22.Text = "2,500";
            // 
            // panel5
            // 
            this.panel5.BackColor = System.Drawing.Color.Transparent;
            this.panel5.Controls.Add(this.label5);
            this.panel5.Controls.Add(this.label21);
            this.panel5.Location = new System.Drawing.Point(25, 478);
            this.panel5.Name = "panel5";
            this.panel5.Size = new System.Drawing.Size(234, 26);
            this.panel5.TabIndex = 34;
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(64)))));
            this.label5.Font = new System.Drawing.Font("Arial Narrow", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label5.ForeColor = System.Drawing.SystemColors.ButtonFace;
            this.label5.Location = new System.Drawing.Point(16, 1);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(19, 24);
            this.label5.TabIndex = 4;
            this.label5.Text = "6";
            // 
            // label21
            // 
            this.label21.AutoSize = true;
            this.label21.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(64)))));
            this.label21.Font = new System.Drawing.Font("Arial Narrow", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label21.ForeColor = System.Drawing.SystemColors.ButtonFace;
            this.label21.Location = new System.Drawing.Point(94, 1);
            this.label21.Name = "label21";
            this.label21.Size = new System.Drawing.Size(51, 24);
            this.label21.TabIndex = 20;
            this.label21.Text = "1,500";
            // 
            // panel4
            // 
            this.panel4.BackColor = System.Drawing.Color.Transparent;
            this.panel4.Controls.Add(this.label6);
            this.panel4.Controls.Add(this.label20);
            this.panel4.Location = new System.Drawing.Point(25, 510);
            this.panel4.Name = "panel4";
            this.panel4.Size = new System.Drawing.Size(234, 30);
            this.panel4.TabIndex = 33;
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(64)))));
            this.label6.Font = new System.Drawing.Font("Arial Narrow", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label6.ForeColor = System.Drawing.SystemColors.ButtonFace;
            this.label6.Location = new System.Drawing.Point(16, 2);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(19, 24);
            this.label6.TabIndex = 5;
            this.label6.Text = "5";
            // 
            // label20
            // 
            this.label20.AutoSize = true;
            this.label20.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(64)))));
            this.label20.Font = new System.Drawing.Font("Arial Narrow", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label20.ForeColor = System.Drawing.SystemColors.ButtonFace;
            this.label20.Location = new System.Drawing.Point(93, 2);
            this.label20.Name = "label20";
            this.label20.Size = new System.Drawing.Size(51, 24);
            this.label20.TabIndex = 19;
            this.label20.Text = "1,000";
            // 
            // panel3
            // 
            this.panel3.BackColor = System.Drawing.Color.Transparent;
            this.panel3.Controls.Add(this.label7);
            this.panel3.Controls.Add(this.label19);
            this.panel3.Location = new System.Drawing.Point(25, 546);
            this.panel3.Name = "panel3";
            this.panel3.Size = new System.Drawing.Size(234, 29);
            this.panel3.TabIndex = 32;
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(64)))));
            this.label7.Font = new System.Drawing.Font("Arial Narrow", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label7.ForeColor = System.Drawing.SystemColors.ButtonFace;
            this.label7.Location = new System.Drawing.Point(16, 4);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(19, 24);
            this.label7.TabIndex = 6;
            this.label7.Text = "4";
            // 
            // label19
            // 
            this.label19.AutoSize = true;
            this.label19.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(64)))));
            this.label19.Font = new System.Drawing.Font("Arial Narrow", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label19.ForeColor = System.Drawing.SystemColors.ButtonFace;
            this.label19.Location = new System.Drawing.Point(94, 4);
            this.label19.Name = "label19";
            this.label19.Size = new System.Drawing.Size(37, 24);
            this.label19.TabIndex = 18;
            this.label19.Text = "500";
            // 
            // panel2
            // 
            this.panel2.BackColor = System.Drawing.Color.Transparent;
            this.panel2.Controls.Add(this.label8);
            this.panel2.Controls.Add(this.label18);
            this.panel2.Location = new System.Drawing.Point(25, 581);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(234, 26);
            this.panel2.TabIndex = 31;
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(64)))));
            this.label8.Font = new System.Drawing.Font("Arial Narrow", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label8.ForeColor = System.Drawing.SystemColors.ButtonFace;
            this.label8.Location = new System.Drawing.Point(16, 1);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(19, 24);
            this.label8.TabIndex = 7;
            this.label8.Text = "3";
            // 
            // label18
            // 
            this.label18.AutoSize = true;
            this.label18.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(64)))));
            this.label18.Font = new System.Drawing.Font("Arial Narrow", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label18.ForeColor = System.Drawing.SystemColors.ButtonFace;
            this.label18.Location = new System.Drawing.Point(93, 1);
            this.label18.Name = "label18";
            this.label18.Size = new System.Drawing.Size(37, 24);
            this.label18.TabIndex = 17;
            this.label18.Text = "300";
            // 
            // panel1
            // 
            this.panel1.BackColor = System.Drawing.Color.Transparent;
            this.panel1.Controls.Add(this.label9);
            this.panel1.Controls.Add(this.label14);
            this.panel1.Location = new System.Drawing.Point(25, 613);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(234, 26);
            this.panel1.TabIndex = 30;
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(64)))));
            this.label9.Font = new System.Drawing.Font("Arial Narrow", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label9.ForeColor = System.Drawing.SystemColors.ButtonFace;
            this.label9.Location = new System.Drawing.Point(16, 1);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(19, 24);
            this.label9.TabIndex = 8;
            this.label9.Text = "2";
            // 
            // label14
            // 
            this.label14.AutoSize = true;
            this.label14.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(64)))));
            this.label14.Font = new System.Drawing.Font("Arial Narrow", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label14.ForeColor = System.Drawing.SystemColors.ButtonFace;
            this.label14.Location = new System.Drawing.Point(94, 1);
            this.label14.Name = "label14";
            this.label14.Size = new System.Drawing.Size(37, 24);
            this.label14.TabIndex = 13;
            this.label14.Text = "200";
            // 
            // pictureBox4
            // 
            this.pictureBox4.Image = global::Proekt_VP.Properties.Resources.Трендо;
            this.pictureBox4.Location = new System.Drawing.Point(49, 9);
            this.pictureBox4.Name = "pictureBox4";
            this.pictureBox4.Size = new System.Drawing.Size(275, 153);
            this.pictureBox4.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox4.TabIndex = 6;
            this.pictureBox4.TabStop = false;
            // 
            // btnOdgovori
            // 
            this.btnOdgovori.DisabledState.BorderColor = System.Drawing.Color.DarkGray;
            this.btnOdgovori.DisabledState.CustomBorderColor = System.Drawing.Color.DarkGray;
            this.btnOdgovori.DisabledState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(169)))), ((int)(((byte)(169)))), ((int)(((byte)(169)))));
            this.btnOdgovori.DisabledState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(141)))), ((int)(((byte)(141)))), ((int)(((byte)(141)))));
            this.btnOdgovori.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.btnOdgovori.ForeColor = System.Drawing.Color.White;
            this.btnOdgovori.Location = new System.Drawing.Point(49, 171);
            this.btnOdgovori.Name = "btnOdgovori";
            this.btnOdgovori.Size = new System.Drawing.Size(275, 45);
            this.btnOdgovori.TabIndex = 7;
            this.btnOdgovori.Text = "TРЕНДО";
            this.btnOdgovori.Click += new System.EventHandler(this.btnOdgovori_Click);
            // 
            // panelPhone
            // 
            this.panelPhone.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(64)))));
            this.panelPhone.Controls.Add(this.label35);
            this.panelPhone.Controls.Add(this.label34);
            this.panelPhone.Controls.Add(this.guna2Button3);
            this.panelPhone.Controls.Add(this.guna2Button2);
            this.panelPhone.Location = new System.Drawing.Point(361, 12);
            this.panelPhone.Name = "panelPhone";
            this.panelPhone.Size = new System.Drawing.Size(303, 236);
            this.panelPhone.TabIndex = 8;
            // 
            // label35
            // 
            this.label35.ForeColor = System.Drawing.Color.Transparent;
            this.label35.Location = new System.Drawing.Point(3, 159);
            this.label35.Name = "label35";
            this.label35.Size = new System.Drawing.Size(297, 64);
            this.label35.TabIndex = 4;
            this.label35.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label34
            // 
            this.label34.ForeColor = System.Drawing.Color.Transparent;
            this.label34.Location = new System.Drawing.Point(16, 12);
            this.label34.Name = "label34";
            this.label34.Size = new System.Drawing.Size(56, 36);
            this.label34.TabIndex = 3;
            this.label34.Text = "<<<";
            this.label34.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.label34.Click += new System.EventHandler(this.label34_Click);
            // 
            // guna2Button3
            // 
            this.guna2Button3.DisabledState.BorderColor = System.Drawing.Color.DarkGray;
            this.guna2Button3.DisabledState.CustomBorderColor = System.Drawing.Color.DarkGray;
            this.guna2Button3.DisabledState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(169)))), ((int)(((byte)(169)))), ((int)(((byte)(169)))));
            this.guna2Button3.DisabledState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(141)))), ((int)(((byte)(141)))), ((int)(((byte)(141)))));
            this.guna2Button3.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(128)))), ((int)(((byte)(0)))));
            this.guna2Button3.Font = new System.Drawing.Font("Segoe UI", 10.2F, System.Drawing.FontStyle.Bold);
            this.guna2Button3.ForeColor = System.Drawing.Color.White;
            this.guna2Button3.Location = new System.Drawing.Point(106, 54);
            this.guna2Button3.Name = "guna2Button3";
            this.guna2Button3.Size = new System.Drawing.Size(180, 45);
            this.guna2Button3.TabIndex = 1;
            this.guna2Button3.Text = "Каролина Гочева";
            this.guna2Button3.Click += new System.EventHandler(this.guna2Button3_Click);
            // 
            // guna2Button2
            // 
            this.guna2Button2.DisabledState.BorderColor = System.Drawing.Color.DarkGray;
            this.guna2Button2.DisabledState.CustomBorderColor = System.Drawing.Color.DarkGray;
            this.guna2Button2.DisabledState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(169)))), ((int)(((byte)(169)))), ((int)(((byte)(169)))));
            this.guna2Button2.DisabledState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(141)))), ((int)(((byte)(141)))), ((int)(((byte)(141)))));
            this.guna2Button2.FillColor = System.Drawing.Color.Red;
            this.guna2Button2.Font = new System.Drawing.Font("Segoe UI", 10.2F, System.Drawing.FontStyle.Bold);
            this.guna2Button2.ForeColor = System.Drawing.Color.White;
            this.guna2Button2.Location = new System.Drawing.Point(106, 3);
            this.guna2Button2.Name = "guna2Button2";
            this.guna2Button2.Size = new System.Drawing.Size(180, 45);
            this.guna2Button2.TabIndex = 0;
            this.guna2Button2.Text = "Горан Пандев";
            this.guna2Button2.Click += new System.EventHandler(this.guna2Button2_Click);
            // 
            // panel17
            // 
            this.panel17.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(64)))));
            this.panel17.Controls.Add(this.NumD);
            this.panel17.Controls.Add(this.NumC);
            this.panel17.Controls.Add(this.NumB);
            this.panel17.Controls.Add(this.NumA);
            this.panel17.Controls.Add(this.progressBar4);
            this.panel17.Controls.Add(this.progressBar3);
            this.panel17.Controls.Add(this.progressBar2);
            this.panel17.Controls.Add(this.progressBar1);
            this.panel17.Controls.Add(this.label40);
            this.panel17.Controls.Add(this.label39);
            this.panel17.Controls.Add(this.label38);
            this.panel17.Controls.Add(this.label37);
            this.panel17.Controls.Add(this.label36);
            this.panel17.Location = new System.Drawing.Point(712, 4);
            this.panel17.Name = "panel17";
            this.panel17.Size = new System.Drawing.Size(285, 244);
            this.panel17.TabIndex = 9;
            // 
            // NumD
            // 
            this.NumD.AutoSize = true;
            this.NumD.ForeColor = System.Drawing.Color.White;
            this.NumD.Location = new System.Drawing.Point(230, 164);
            this.NumD.Name = "NumD";
            this.NumD.Size = new System.Drawing.Size(0, 16);
            this.NumD.TabIndex = 17;
            // 
            // NumC
            // 
            this.NumC.AutoSize = true;
            this.NumC.ForeColor = System.Drawing.Color.White;
            this.NumC.Location = new System.Drawing.Point(231, 116);
            this.NumC.Name = "NumC";
            this.NumC.Size = new System.Drawing.Size(0, 16);
            this.NumC.TabIndex = 16;
            // 
            // NumB
            // 
            this.NumB.AutoSize = true;
            this.NumB.ForeColor = System.Drawing.Color.White;
            this.NumB.Location = new System.Drawing.Point(234, 77);
            this.NumB.Name = "NumB";
            this.NumB.Size = new System.Drawing.Size(0, 16);
            this.NumB.TabIndex = 15;
            // 
            // NumA
            // 
            this.NumA.AutoSize = true;
            this.NumA.ForeColor = System.Drawing.Color.White;
            this.NumA.Location = new System.Drawing.Point(230, 43);
            this.NumA.Name = "NumA";
            this.NumA.Size = new System.Drawing.Size(0, 16);
            this.NumA.TabIndex = 14;
            // 
            // progressBar4
            // 
            this.progressBar4.Location = new System.Drawing.Point(67, 158);
            this.progressBar4.Name = "progressBar4";
            this.progressBar4.Size = new System.Drawing.Size(161, 23);
            this.progressBar4.TabIndex = 12;
            // 
            // progressBar3
            // 
            this.progressBar3.Location = new System.Drawing.Point(67, 116);
            this.progressBar3.Name = "progressBar3";
            this.progressBar3.Size = new System.Drawing.Size(161, 23);
            this.progressBar3.TabIndex = 11;
            // 
            // progressBar2
            // 
            this.progressBar2.Location = new System.Drawing.Point(67, 77);
            this.progressBar2.Name = "progressBar2";
            this.progressBar2.Size = new System.Drawing.Size(161, 23);
            this.progressBar2.TabIndex = 10;
            // 
            // progressBar1
            // 
            this.progressBar1.Location = new System.Drawing.Point(67, 41);
            this.progressBar1.Name = "progressBar1";
            this.progressBar1.Size = new System.Drawing.Size(161, 23);
            this.progressBar1.TabIndex = 9;
            // 
            // label40
            // 
            this.label40.ForeColor = System.Drawing.Color.Transparent;
            this.label40.Location = new System.Drawing.Point(16, 152);
            this.label40.Name = "label40";
            this.label40.Size = new System.Drawing.Size(56, 36);
            this.label40.TabIndex = 8;
            this.label40.Text = "D";
            this.label40.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label39
            // 
            this.label39.ForeColor = System.Drawing.Color.Transparent;
            this.label39.Location = new System.Drawing.Point(16, 33);
            this.label39.Name = "label39";
            this.label39.Size = new System.Drawing.Size(56, 36);
            this.label39.TabIndex = 7;
            this.label39.Text = "A";
            this.label39.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label38
            // 
            this.label38.ForeColor = System.Drawing.Color.Transparent;
            this.label38.Location = new System.Drawing.Point(16, 69);
            this.label38.Name = "label38";
            this.label38.Size = new System.Drawing.Size(56, 36);
            this.label38.TabIndex = 6;
            this.label38.Text = "B";
            this.label38.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label37
            // 
            this.label37.ForeColor = System.Drawing.Color.Transparent;
            this.label37.Location = new System.Drawing.Point(16, 105);
            this.label37.Name = "label37";
            this.label37.Size = new System.Drawing.Size(56, 36);
            this.label37.TabIndex = 5;
            this.label37.Text = "C";
            this.label37.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label36
            // 
            this.label36.ForeColor = System.Drawing.Color.Transparent;
            this.label36.Location = new System.Drawing.Point(16, 2);
            this.label36.Name = "label36";
            this.label36.Size = new System.Drawing.Size(56, 36);
            this.label36.TabIndex = 4;
            this.label36.Text = "<<<";
            this.label36.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.label36.Click += new System.EventHandler(this.label36_Click);
            // 
            // OptionA
            // 
            this.OptionA.Location = new System.Drawing.Point(116, 421);
            this.OptionA.Name = "OptionA";
            this.OptionA.Size = new System.Drawing.Size(379, 135);
            this.OptionA.TabIndex = 10;
            this.OptionA.Tag = "1";
            this.OptionA.UseVisualStyleBackColor = true;
            this.OptionA.Click += new System.EventHandler(this.ProveriOdgovor);
            // 
            // OptionB
            // 
            this.OptionB.Location = new System.Drawing.Point(712, 421);
            this.OptionB.Name = "OptionB";
            this.OptionB.Size = new System.Drawing.Size(384, 135);
            this.OptionB.TabIndex = 11;
            this.OptionB.Tag = "2";
            this.OptionB.UseVisualStyleBackColor = true;
            this.OptionB.Click += new System.EventHandler(this.ProveriOdgovor);
            // 
            // OptionC
            // 
            this.OptionC.Location = new System.Drawing.Point(116, 583);
            this.OptionC.Name = "OptionC";
            this.OptionC.Size = new System.Drawing.Size(379, 130);
            this.OptionC.TabIndex = 12;
            this.OptionC.Tag = "3";
            this.OptionC.UseVisualStyleBackColor = true;
            this.OptionC.Click += new System.EventHandler(this.ProveriOdgovor);
            // 
            // OptionD
            // 
            this.OptionD.Location = new System.Drawing.Point(712, 583);
            this.OptionD.Name = "OptionD";
            this.OptionD.Size = new System.Drawing.Size(384, 130);
            this.OptionD.TabIndex = 13;
            this.OptionD.Tag = "4";
            this.OptionD.UseVisualStyleBackColor = true;
            this.OptionD.Click += new System.EventHandler(this.ProveriOdgovor);
            // 
            // timer1
            // 
            this.timer1.Interval = 7000;
            this.timer1.Tick += new System.EventHandler(this.timer1_Tick);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.White;
            this.ClientSize = new System.Drawing.Size(1524, 725);
            this.Controls.Add(this.OptionD);
            this.Controls.Add(this.OptionC);
            this.Controls.Add(this.OptionB);
            this.Controls.Add(this.OptionA);
            this.Controls.Add(this.panel17);
            this.Controls.Add(this.panelPhone);
            this.Controls.Add(this.btnOdgovori);
            this.Controls.Add(this.pictureBox4);
            this.Controls.Add(this.guna2ShadowPanel1);
            this.Controls.Add(this.guna2CustomGradientPanel1);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Name = "Form1";
            this.Text = "Form1";
            this.guna2CustomGradientPanel1.ResumeLayout(false);
            this.guna2CustomGradientPanel1.PerformLayout();
            this.guna2ShadowPanel1.ResumeLayout(false);
            this.guna2ShadowPanel1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox3)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            this.panel16.ResumeLayout(false);
            this.panel16.PerformLayout();
            this.panel15.ResumeLayout(false);
            this.panel15.PerformLayout();
            this.panel13.ResumeLayout(false);
            this.panel13.PerformLayout();
            this.panel12.ResumeLayout(false);
            this.panel12.PerformLayout();
            this.panel11.ResumeLayout(false);
            this.panel11.PerformLayout();
            this.panel10.ResumeLayout(false);
            this.panel10.PerformLayout();
            this.panel9.ResumeLayout(false);
            this.panel9.PerformLayout();
            this.panel8.ResumeLayout(false);
            this.panel8.PerformLayout();
            this.panel7.ResumeLayout(false);
            this.panel7.PerformLayout();
            this.panel6.ResumeLayout(false);
            this.panel6.PerformLayout();
            this.panel5.ResumeLayout(false);
            this.panel5.PerformLayout();
            this.panel4.ResumeLayout(false);
            this.panel4.PerformLayout();
            this.panel3.ResumeLayout(false);
            this.panel3.PerformLayout();
            this.panel2.ResumeLayout(false);
            this.panel2.PerformLayout();
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox4)).EndInit();
            this.panelPhone.ResumeLayout(false);
            this.panel17.ResumeLayout(false);
            this.panel17.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private Guna.UI2.WinForms.Guna2CustomGradientPanel guna2CustomGradientPanel1;
        private Guna.UI2.WinForms.Guna2ShadowPanel guna2ShadowPanel1;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label14;
        private System.Windows.Forms.Label label17;
        private System.Windows.Forms.Label label16;
        private System.Windows.Forms.Label label15;
        private System.Windows.Forms.Label label27;
        private System.Windows.Forms.Label label26;
        private System.Windows.Forms.Label label25;
        private System.Windows.Forms.Label label24;
        private System.Windows.Forms.Label label23;
        private System.Windows.Forms.Label label22;
        private System.Windows.Forms.Label label21;
        private System.Windows.Forms.Label label20;
        private System.Windows.Forms.Label label19;
        private System.Windows.Forms.Label label18;
        private System.Windows.Forms.Label label30;
        private System.Windows.Forms.Label label29;
        private System.Windows.Forms.Label label28;
        private System.Windows.Forms.Panel panel2;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Panel panel3;
        private System.Windows.Forms.Panel panel4;
        private System.Windows.Forms.Panel panel5;
        private System.Windows.Forms.Panel panel7;
        private System.Windows.Forms.Panel panel6;
        private System.Windows.Forms.Panel panel9;
        private System.Windows.Forms.Panel panel8;
        private System.Windows.Forms.Panel panel12;
        private System.Windows.Forms.Panel panel11;
        private System.Windows.Forms.Panel panel10;
        private System.Windows.Forms.Panel panel13;
        private System.Windows.Forms.Panel panel16;
        private System.Windows.Forms.Label label31;
        private System.Windows.Forms.Label label32;
        private System.Windows.Forms.Panel panel15;
        private System.Windows.Forms.PictureBox pictureBox3;
        private System.Windows.Forms.PictureBox pictureBox2;
        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.TextBox tbOsvoeniSredstva;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label13;
        private System.Windows.Forms.Label label33;
        private System.Windows.Forms.PictureBox pictureBox4;
        private Guna.UI2.WinForms.Guna2Button btnOdgovori;
        private System.Windows.Forms.Panel panelPhone;
        private Guna.UI2.WinForms.Guna2Button guna2Button3;
        private Guna.UI2.WinForms.Guna2Button guna2Button2;
        private System.Windows.Forms.Panel panel17;
        private System.Windows.Forms.Label label34;
        private System.Windows.Forms.Label label35;
        private System.Windows.Forms.Label label40;
        private System.Windows.Forms.Label label39;
        private System.Windows.Forms.Label label38;
        private System.Windows.Forms.Label label37;
        private System.Windows.Forms.Label label36;
        private System.Windows.Forms.ProgressBar progressBar4;
        private System.Windows.Forms.ProgressBar progressBar3;
        private System.Windows.Forms.ProgressBar progressBar2;
        private System.Windows.Forms.ProgressBar progressBar1;
        private System.Windows.Forms.Button OptionA;
        private System.Windows.Forms.Button OptionB;
        private System.Windows.Forms.Button OptionC;
        private System.Windows.Forms.Button OptionD;
        private System.Windows.Forms.Label NumD;
        private System.Windows.Forms.Label NumC;
        private System.Windows.Forms.Label NumB;
        private System.Windows.Forms.Label NumA;
        private System.Windows.Forms.Timer timer1;
    }
}

